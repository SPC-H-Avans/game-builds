<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="interactable1" tilewidth="16" tileheight="16" tilecount="5" columns="5">
 <image source="interactable1.png" width="80" height="16"/>
</tileset>
